#ifndef QABC_H
#define QABC_H

#include <QObject>
#include <QDebug>

#include "clsCMulatorABC.h"
#include "ResultsStats.hpp"

class QABC : public QObject
{
    Q_OBJECT
public:
    explicit QABC( ActualDataFile actual,  ZParams params, std::size_t reps, std::size_t batch_num, FactorToInfer f, QObject *parent = nullptr);

    std::vector<SimulationResult> GetResultsVector(bool only_accepted_results);

    void RunABCInferenceGUI();

    void SetActualData(  ) ;
    void SetParameters(  );

    void TestFunction();

    QString GetOutputText() { return strOutputSummary; }

signals:
    //void stopABC();

    void interruptedABC();
    void batch_completed(int percent_completed);
    void finishedABC();

    void finishedSimulations();
    void finishedDistanceCalculations();
    void finishedSorting();


public slots:
    void on_stop_ABC();

private:
    FactorToInfer factor;
    std::size_t number_of_batches;
    std::size_t repeats;
    std::size_t remaining_repeats;
    std::size_t repeats_in_batch;

    std::vector<SimulationResult> simulation_result_vector;

    ActualDataFile actual_data_file;
    ZParams my_zparams;

    bool is_allowed_to_run;

    QString strOutputSummary;
};

#endif // QABC_H
