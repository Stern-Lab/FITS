//
//  PriorSampler.cpp
//  fits
//
//  Created by Tal Zinger on 14/11/2016.
//  Copyright © 2016 Stern Lab. All rights reserved.
//

#include "PriorSampler.hpp"

