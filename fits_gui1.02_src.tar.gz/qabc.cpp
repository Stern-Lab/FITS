/*
    FITS - Flexible Inference from Time-Series data
    (c) 2016-2018 by Tal Zinger
    tal.zinger@outlook.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "qabc.h"


/* To be used instead of RunABCInference in order to give proper user responsiveness */
void QABC::RunABCInferenceGUI()
{
    qDebug() << "ABC from QABC";

    // initialize abc object
    qDebug() << "params for example " << my_zparams.GetFloat("_mutation_rate1_1", -1.8);
    qDebug() << "actual data for example " << actual_data_file.GetNumberOfAlleles();

    clsCMulatorABC abc_object_sim( my_zparams, actual_data_file );

    abc_object_sim.SetImmediateRejection(false);

    qDebug() << "repeats " << repeats;
    qDebug() << "number_of_batches " << number_of_batches;

    simulation_result_vector.clear();
    simulation_result_vector.reserve(repeats);

    remaining_repeats = repeats;
    repeats_in_batch = repeats / number_of_batches;

    // most important part is responsiveness through the course of inference
    while ( remaining_repeats > 0 && is_allowed_to_run ) {

        if (repeats_in_batch > remaining_repeats) {
            repeats_in_batch = remaining_repeats;
        }
        remaining_repeats -= repeats_in_batch;

        std::vector<SimulationResult> tmp_result_vector;


        switch (factor) {
        case Fitness:
            tmp_result_vector = abc_object_sim.RunFitnessInferenceBatch(repeats_in_batch);
            break;

        case PopulationSize:
            tmp_result_vector = abc_object_sim.RunPopulationSizeInferenceBatch(repeats_in_batch);
            break;

        case MutationRate:
            tmp_result_vector = abc_object_sim.RunMutationInferenceBatch(repeats_in_batch);
            break;

        case Generations:
            tmp_result_vector = abc_object_sim.RunGenerationInferenceBatch(repeats_in_batch);
            break;
        }
        auto end = std::chrono::high_resolution_clock::now();

        for ( auto &tmp_result : tmp_result_vector ) {
            simulation_result_vector.push_back(tmp_result);
        }

        int current_percent = ( repeats - remaining_repeats ) * 100 / repeats;

        // this is to help prevent emitting the batch_completed if needs to stop
        if (!is_allowed_to_run) {
            emit interruptedABC();
            return;
        }
        emit batch_completed(current_percent);


        //qDebug() << current_percent;

    } // while (remaining_repeats > 0)

    if (!is_allowed_to_run) {
        emit interruptedABC();
        return;
    }
    emit finishedSimulations();


    qDebug() << "Calculating distance... ";

    // scaling factor; default actualling means no scaling (divide by 1)
    std::vector<FLOAT_TYPE> scaling_vector(0);

    auto scaling_option_str = my_zparams.GetString( fits_constants::PARAM_SCALING,
                                                    fits_constants::PARAM_SCALING_DEFAULT );

    if ( scaling_option_str.compare(fits_constants::PARAM_SCALING_SD) == 0 ) {
        scaling_vector = abc_object_sim.GetSDPerAllele(0, simulation_result_vector.size());
    }

    if ( scaling_option_str.compare(fits_constants::PARAM_SCALING_MAD) == 0) {
        scaling_vector = abc_object_sim.GetMADPerAllele(0, simulation_result_vector.size());
    }


    // get actual data matrix
    auto actual_generations = actual_data_file.GetActualGenerations();
    auto actual_matrix = actual_data_file.GetActualFreqsAsMatrix();

    // from each simulation result, get only the relevant generations
    for ( auto current_idx=0; current_idx<simulation_result_vector.size(); ++current_idx ) {
        simulation_result_vector[current_idx].distance_from_actual =
                abc_object_sim.GetDistanceSimActual(actual_matrix, simulation_result_vector[current_idx].sim_data_matrix, scaling_vector );
    }

    // this is to help prevent emitting signals if needs to stop
    if (!is_allowed_to_run) {
        emit interruptedABC();
        return;
    }
    emit finishedDistanceCalculations();

    qDebug() << "Sorting...";

    std::sort(simulation_result_vector.begin(), simulation_result_vector.end());

    // this is to help prevent emitting signals if needs to stop
    if (!is_allowed_to_run) {
        emit interruptedABC();
        return;
    }
    emit finishedSorting();

    qDebug() <<"emitting finishedABC";

    // this is to help prevent emitting signals if needs to stop
    if (!is_allowed_to_run) {
        emit interruptedABC();
        return;
    }
    emit finishedABC();
}

void QABC::on_stop_ABC()
{
    qDebug() << "Stopping ABC";
    is_allowed_to_run = false;
}

void QABC::TestFunction()
{
    for ( auto i=0; i<100; ++i ) {
        qDebug() << i;
    }
}

QABC::QABC( ActualDataFile actual,  ZParams params, std::size_t reps, std::size_t batch_num, FactorToInfer f, QObject *parent) :
    actual_data_file(actual),
    repeats(reps),
    my_zparams(params),
    number_of_batches(batch_num),
    is_allowed_to_run(true),
    simulation_result_vector(0),
    factor(f)
  //QABC::QABC(QObject *parent) : QObject(parent)
{
    qDebug() << "params for example " << my_zparams.GetFloat("_mutation_rate1_1", -1.2);
    qDebug() << "actual data for example " << actual_data_file.GetNumberOfAlleles();
}

std::vector<SimulationResult> QABC::GetResultsVector(bool only_accepted_results)
{
    if (only_accepted_results) {

        auto rejection_threshold = my_zparams.GetFloat( fits_constants::PARAM_REJECTION_THRESHOLD, -1.0f );

        std::size_t sims_to_keep = 0;
        sims_to_keep = my_zparams.GetFloat( fits_constants::PARAM_ACCEPTANCE_RATE,
                                               fits_constants::ACCEPTANCE_RATE_DEFAULT ) * repeats;

        if ( rejection_threshold > 0.0f ) {
            std::cout << "Using rejection threshold" << rejection_threshold << std::endl;

            if (!std::is_sorted(simulation_result_vector.cbegin(),
                                simulation_result_vector.cend() ) ) {
                std::cerr << "GetResultsVector: results vector is not sorted!" << std::endl;
                throw "GetResultsVector: results vector is not sorted!";
            }

            std::cout << "test" << std::endl;
            int current_idx=0;
            while ( current_idx < simulation_result_vector.size() &&
                   simulation_result_vector[current_idx].distance_from_actual < rejection_threshold ) {
                //std::cout << "distance=" << simulation_result_vector[current_idx].distance_from_actual << std::endl;
                ++current_idx;
            }
            sims_to_keep = current_idx - 1;

            if ( sims_to_keep > simulation_result_vector.size() ) {
                sims_to_keep = simulation_result_vector.size();
            }
        }

        // find the first item to hold distance>0
        std::size_t first_nonzero_distance_idx = 0;

        /*
        while ( first_nonzero_distance_idx<_simulation_result_vector.size() &&
               _simulation_result_vector[first_nonzero_distance_idx].distance_from_actual==0.0f ) {
            ++first_nonzero_distance_idx;
        }
        */

        std::nth_element(simulation_result_vector.begin() + first_nonzero_distance_idx,
                         simulation_result_vector.begin() + first_nonzero_distance_idx + sims_to_keep,
                         simulation_result_vector.end());

        std::vector<SimulationResult> tmp_vec( simulation_result_vector.begin() + first_nonzero_distance_idx,
                                               simulation_result_vector.begin() + first_nonzero_distance_idx + sims_to_keep );

        // std::cout << "sims " << _sims_to_keep << std::endl;
        // std::cout << "tmpvec " << tmp_vec.size() << std::endl;

        return tmp_vec;
    }

    return simulation_result_vector;
}
