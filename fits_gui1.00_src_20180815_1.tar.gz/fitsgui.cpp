#include "fitsgui.h"
#include "ui_fitsgui.h"
#include "fits_constants.h"
#include <iomanip>

void FitsGUI::on_sorting_complete()
{

}

void FitsGUI::on_distance_complete()
{
    ui->lblProgress->setText("Sorting results...");
}

void FitsGUI::on_simulations_complete()
{
    ui->lblProgress->setText("Calculating distance...");
}


void FitsGUI::on_batch_completed(int percent_completed)
{
    ui->progressBar->setValue(percent_completed);
    ui->lblProgress->setText( QString::number(percent_completed) + "% simulations done");

    auto current_update = std::chrono::high_resolution_clock::now();
    auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(current_update - last_update);

    auto calculated_speed = static_cast<double>(percent_completed-last_percent) / static_cast<double>(elapsed_ms.count());
    calculated_speed *= 1000; // 1/milisecond to 1/second

    auto seconds_remaining = (100-percent_completed) / static_cast<int>(std::round(calculated_speed));
    auto duration_remaining = std::chrono::seconds(seconds_remaining);
    auto current_time = std::chrono::system_clock::now();
    auto completion_ETA = current_time + duration_remaining;
    auto completion_ETA_timet = std::chrono::system_clock::to_time_t(completion_ETA);
    auto completion_ETA_tm = *std::localtime(&completion_ETA_timet);

    ui->txtOutput->setText("Running simulations...\n");

    std::stringstream ss;
    ss << "Running simulations..." << std::endl;
    ss << "ETA: " << std::put_time(&completion_ETA_tm, "%c") << std::endl;;
    auto completion_eta_str = ss.str();

    ui->txtOutput->setText( QString::fromStdString(completion_eta_str) );



    last_update = current_update;
    last_percent = percent_completed;
}

void FitsGUI::on_ABC_stop()
{
    ui->cmdGo->setEnabled(true);
    ui->cmdStop->setEnabled(false);
    ui->cmdSavePosterior->setEnabled(false);
    ui->cmdSaveSummary->setEnabled(false);
}

FitsGUI::FitsGUI(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FitsGUI),
    simulation_result_vector(0),
    loaded_parameters(false),
    loaded_actual_data(false)
{
    ui->setupUi(this);

    QString str_title = QString::fromStdString( "FITS " ) + QString::fromStdString(fits_constants::current_version_str);
    setWindowTitle( str_title );
    /*
    //ui->lblInitFreqs->setEnabled(false);
    //ui->tblInitFreqs->setEnabled(false);

    //ui->lblAlleleFitness->setEnabled(false);
    //ui->tblAlleleFitness->setEnabled(false);

    //ui->lblFitnessRange->setEnabled(false);
    //ui->tblFitnessRange->setEnabled(false);

    ui->lblGenerations->setEnabled(false);
    ui->txtGenerations->setEnabled(false);

    ui->lblAlleles->setEnabled(false);
    ui->txtNumAlleles->setEnabled(false);

    ui->lblMutationRates->setEnabled(false);
    ui->tblMutrates->setEnabled(false);

    ui->lblPopsize->setEnabled(false);
    ui->txtPopsize->setEnabled(false);

    ui->lblSampleSize->setEnabled(false);
    ui->txtSampleSize->setEnabled(false);

    ui->lblMaxMutrates->setEnabled(false);
    ui->tblMaxMutationRates->setEnabled(false);

    ui->lblMinMutrates->setEnabled(false);
    ui->tblMinMutationRates->setEnabled(false);

    ui->lblPopsizeRange->setEnabled(false);
    ui->tblPopsizeRange->setEnabled(false);
    */
}

FitsGUI::~FitsGUI()
{
    delete ui;
}

void FitsGUI::on_cmdBrowseActualData_clicked()
{
    auto filename = QFileDialog::getOpenFileName(this,
                                                 tr("Open Actual Data File"), "/Users/talzinger/Nobackup/Test/", tr("Text Files (*.txt)"));

    if ( filename.isEmpty() ) {
        qDebug() << "no filename chosen";
        return;
    }
    ui->txtActualData->setText(filename);

    std::string strFilename = ui->txtActualData->text().toStdString();

    actual_data_file.LoadActualData(strFilename);

    loaded_actual_data = true;
}

void FitsGUI::on_cmdBrowseParameters_clicked()
{
    auto filename = QFileDialog::getOpenFileName(this,
                                                 tr("Open Parameter File"), "/Users/talzinger/Nobackup/Test/", tr("Text Files (*.txt)"));

    if ( filename.isEmpty() ) {
        qDebug() << "no filename chosen";
        return;
    }
    ui->txtParameters->setText(filename);

    on_cmdReloadParameters_clicked();

    ui->cmdReloadParameters->setEnabled(true);
    ui->cmdEditParameterFile->setEnabled(true);
}

void FitsGUI::on_cmdStop_clicked()
{
    ui->cmdStop->setEnabled(false);
    ui->lblProgress->setText("Stopping...");
    emit stopABC();
}

void FitsGUI::on_ABC_completed()
{

    ui->lblProgress->setText("Preparing report...");

    QString strOutputSummary;
    // report

    qDebug() << "result status";
    ResultsStats result_stats(my_zparams);
    qDebug() << "results initialized";


    auto accepted_results_vector = qabc->GetResultsVector(true);

    ui->txtOutput->append("Done.\n");
    result_stats.SetRejectionThreshold( my_zparams.GetFloat( fits_constants::PARAM_REJECTION_THRESHOLD, 0.0f ) );
    qDebug() << "set threshold";
    auto single_mutation_rate = my_zparams.GetFloat( fits_constants::PARAM_SINGLE_MUTATION_RATE, 0.0f );
    result_stats.SetSingleMutrateUsed( single_mutation_rate != 0.0f );

    ui->txtOutput->append("Preparing report... ");

    switch (factor) {
    case Fitness: {
        result_stats.SetPriorDistrib( my_zparams.GetString(fits_constants::PARAM_PRIOR_DISTRIB, fits_constants::PARAM_PRIOR_DISTRIB_DEFAULT ) );
        result_stats.CalculateStatsFitness(accepted_results_vector);

        str_summary = QString::fromStdString( result_stats.GetSummaryFitness() );
        str_posterior = QString::fromStdString(result_stats.GetFitnessDistrib(accepted_results_vector));

        break;
    }

    case PopulationSize: {
        result_stats.CalculateStatsPopulationSize(accepted_results_vector);

        str_summary = QString::fromStdString( result_stats.GetSummaryPopSize() );
        str_posterior = QString::fromStdString(result_stats.GetPopsizeDistrib(accepted_results_vector));

        break;
    }

    case MutationRate: {
        auto infer_single_mutrate = my_zparams.GetInt(fits_constants::PARAM_MIN_LOG_SINGLE_MUTATION_RATE, 0);

        result_stats.SetSingleMutrateInferred( infer_single_mutrate != 0 );
        result_stats.CalculateStatsMutation(accepted_results_vector);

        str_summary = QString::fromStdString( result_stats.GetSummaryMutRate() );
        str_posterior = QString::fromStdString(result_stats.GetMutrateDistrib(accepted_results_vector));

        break;
    }

    case Generations: {
        // this is currently not implemented
        break;
    }
    }

    ui->progressBar->setValue(0);
    ui->lblProgress->setText("Ready.");
    ui->txtOutput->setText(str_summary);

    ui->cmdSavePosterior->setEnabled(true);
    ui->cmdSaveSummary->setEnabled(true);
    ui->cmdGo->setEnabled(true);
    ui->cmdStop->setEnabled(false);
}

void FitsGUI::on_optSingleSimulation_clicked()
{
    // Basically loading parameter file would enable this button and no additional
    // checks are needed...
}

void FitsGUI::on_optFitnessInference_clicked()
{
    if (!loaded_actual_data) {
        QMessageBox msgBox;
        msgBox.setText("Actual data file not loaded. Please load one.");
        ui->cmdBrowseActualData->setFocus();
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        ui->optSingleSimulation->setChecked(true);
        return;
    }
}

void FitsGUI::on_radioButton_3_clicked()
{
    on_optFitnessInference_clicked();
}

void FitsGUI::on_radioButton_4_clicked()
{
    on_optFitnessInference_clicked();
}

void FitsGUI::on_cmdSaveSummary_clicked()
{
    // tr is for localization
    auto filename = QFileDialog::getSaveFileName( this,
                                                  tr("Save Summary As"),
                                                  "/summary.txt",
                                                  tr("Text File (*.txt)") );

    qDebug() << filename;

    if ( filename.isEmpty() || filename.isNull() ) {
        return;
    }

    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for writing");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }

    QTextStream out(&file);
    out << str_summary;

    file.close();
}

void FitsGUI::on_cmdSavePosterior_clicked()
{
    // tr is for localization
    auto filename = QFileDialog::getSaveFileName( this,
                                                  tr("Save Posterior As"),
                                                  "/posterior.txt",
                                                  tr("Text File (*.txt)") );

    qDebug() << filename;

    if ( filename.isEmpty() || filename.isNull() ) {
        return;
    }

    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for writing");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }


    QTextStream out(&file);
    out << str_posterior;

    file.close();
}

void FitsGUI::on_cmdGo_clicked()
{
    last_update = std::chrono::high_resolution_clock::now();
    last_percent = 0;

    if (!loaded_parameters) {
        QMessageBox msgBox;
        msgBox.setText("Parameters not loaded - please load a parameter file.");
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }

    if ( ui->optSingleSimulation->isChecked() ) {

        CMulator sim_object;

        sim_object.InitMemberVariables(my_zparams);

        if ( !sim_object.IsAbleToSimulate() ) {
            QMessageBox msgBox;
            msgBox.setText("Insufficient parameters for single simulation.");
            msgBox.setStandardButtons(QMessageBox::Ok);
            msgBox.setDefaultButton(QMessageBox::Ok);
            msgBox.exec();
            return;
        }

        ui->cmdSaveSummary->setEnabled(false);
        ui->cmdSavePosterior->setEnabled(false);
        ui->cmdGo->setEnabled(false);
        ui->cmdStop->setEnabled(true);

        sim_object.EvolveAllGenerations();

        auto str_result = sim_object.GetAllOutputAsTextForR();

        str_summary = QString::fromStdString(str_result);
        ui->txtOutput->setText(str_summary);

        ui->cmdSaveSummary->setEnabled(true);
        ui->cmdGo->setEnabled(true);
        ui->cmdStop->setEnabled(false);

        return;
    }


    // all the rest of the options are inference
    // first, check that we have an actual data file loaded
    on_optFitnessInference_clicked();

    // if we got here, then we have an actual data file
    ui->cmdSaveSummary->setEnabled(false);
    ui->cmdSavePosterior->setEnabled(false);
    ui->cmdGo->setEnabled(false);
    ui->cmdStop->setEnabled(true);

    repeats = my_zparams.GetInt(fits_constants::PARAM_SIM_REPEATS);
    number_of_batches = 100;

    factor = FactorToInfer::None;

    if ( ui->optFitnessInference->isChecked() ) {
        // todo: verify there's enough data to infer fitness
        factor = FactorToInfer::Fitness;
    }

    if ( ui->optMutationInference->isChecked() ) {
        // todo: verify there's enough data to infer mutrate
        factor = FactorToInfer::MutationRate;
    }

    if ( ui->optPopsizeInference->isChecked() ) {
        // todo: verify there's enough data to infer popsize
        factor = FactorToInfer::PopulationSize;
    }

    if ( factor == FactorToInfer::None ) {
        QMessageBox msgBox;
        msgBox.setText("Undefined factor to infer. Please choose.");
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }

    qabc = new QABC( actual_data_file, my_zparams, repeats, number_of_batches, factor );

    QFuture<void> res = QtConcurrent::run( qabc, &QABC::RunABCInferenceGUI );

    ui->txtOutput->setText("Running simulations...\n");

    connect( qabc, &QABC::batch_completed, this, &FitsGUI::on_batch_completed );
    connect( this, &FitsGUI::stopABC, qabc, &QABC::on_stop_ABC );
    connect( qabc, &QABC::finishedABC, this, &FitsGUI::on_ABC_completed );
    connect( qabc, &QABC::finishedSimulations, this, &FitsGUI::on_simulations_complete );
    connect( qabc, &QABC::finishedDistanceCalculations, this, &FitsGUI::on_distance_complete );
    connect( qabc, &QABC::finishedSorting, this, &FitsGUI::on_sorting_complete );
    connect( qabc, &QABC::interruptedABC, this, &FitsGUI::on_ABC_stop );
}


void FitsGUI::on_cmdReloadParameters_clicked()
{

    ui->optSingleSimulation->setEnabled(false);
    ui->optFitnessInference->setEnabled(false);
    ui->optMutationInference->setEnabled(false);
    ui->optPopsizeInference->setEnabled(false);
    ui->cmdGo->setEnabled(false);

    std::string strFilename = ui->txtParameters->text().toStdString();

    try {
        my_zparams.Clear();
        my_zparams.ReadParameters(strFilename, false);
    }
    catch(...) {
        qDebug() << "Error while reading parameters.";
        return;
    }

    ui->txtAllParameters->setText( QString("<b>Loaded parameters from file:</b> " + QString::fromStdString( strFilename) ) );

    std::string str_param;
    int num_alleles = -1;
    try {
        num_alleles = my_zparams.GetInt( fits_constants::PARAM_NUM_ALLELES );
    }
    catch(...) {
        qDebug() << "Error while reading basic parameters (number of alleles).";
        return;
    }

    // defined fitness values
    try {
        // dummy read just to throw us out if it doesn't exist
        std::string dummy_fitness_str = fits_constants::PARAM_ALLELE_FITNESS + std::to_string(0);
        auto dummy_fitness_val = my_zparams.GetFloat(dummy_fitness_str);
        ui->txtAllParameters->append(QString("<br><b>Fitness Values<br>===============</b>") );

        ui->optSingleSimulation->setEnabled(true);
        ui->optSingleSimulation->setChecked(true);
        ui->cmdGo->setEnabled(true);

        for ( auto current_allele=0; current_allele<num_alleles; ++current_allele ) {
            std::string tmp_fitness_str = fits_constants::PARAM_ALLELE_FITNESS + std::to_string(current_allele);

            auto tmp_fitness_val = my_zparams.GetFloat(tmp_fitness_str);

            ui->txtAllParameters->append( QString("<b>Allele ") + QString::number(current_allele) +
                                          QString(" fitness: </b> ") + QString::number(tmp_fitness_val) );
        }
    }
    catch(...) {
        qDebug() << "error while reading fitness value data";
    }


    ui->txtAllParameters->append(QString("<br><b>Basic Parameters<br>=================</b>") );
    try {

        str_param = my_zparams.GetString( fits_constants::PARAM_POPULATION_SIZE, "--" );
        ui->txtAllParameters->append(QString("<b>Population size: </b>") + QString::fromStdString(str_param) );

        str_param = my_zparams.GetString( fits_constants::PARAM_SAMPLE_SIZE, "--" );
        ui->txtAllParameters->append(QString("<b>Sample size: </b>") + QString::fromStdString(str_param) );

        ui->txtAllParameters->append(QString("<b>Alleles: </b>") + QString::number(num_alleles) );

        str_param = my_zparams.GetString( fits_constants::PARAM_NUM_GENERATIONS, "--" );
        ui->txtAllParameters->append(QString("<b>Generations: </b>") + QString::fromStdString(str_param) );

        str_param = my_zparams.GetString( fits_constants::PARAM_SIM_REPEATS, "" );
        if ( !str_param.empty() ) {
            ui->txtAllParameters->append(QString("<b>Repeats: </b>") + QString::fromStdString(str_param) );
        }

        str_param = my_zparams.GetString( fits_constants::PARAM_ACCEPTANCE_RATE, "" );
        if ( !str_param.empty() ) {
            ui->txtAllParameters->append(QString("<b>Acceptance rate: </b>") + QString::fromStdString(str_param) );
        }

        str_param = my_zparams.GetString( fits_constants::PARAM_PRIOR_DISTRIB, "?" );
        if ( !str_param.empty() ) {
            ui->txtAllParameters->append(QString("<b>Prior distribution: </b>") + QString::fromStdString(str_param) );
        }
    }
    catch(...) {
        qDebug() << "Error while reading basic parameters.";
        return;
    }

    // defined mutation rates
    try {
        // dummy read just to throw us out if it doesn't exist
        std::string tmp_str_mutrate = fits_constants::PARAM_MUTATION_RATE + "0_0";
        auto dummy_val = my_zparams.GetFloat(tmp_str_mutrate);

        ui->txtAllParameters->append(QString("<br><b>Mutation Rates<br>===============</b>") );

        for ( auto from_allele=0; from_allele<num_alleles; ++from_allele ) {
            for ( auto to_allele=0; to_allele<num_alleles; ++to_allele ) {
                std::string tmp_str_mutrate = fits_constants::PARAM_MUTATION_RATE +
                        std::to_string(from_allele) +
                        "_" +
                        std::to_string(to_allele);

                auto tmp_mutrate_val = my_zparams.GetFloat(tmp_str_mutrate);
                auto str_mutrate_val = QString::number(tmp_mutrate_val);

                ui->txtAllParameters->append(QString("<b>From " + QString::number(from_allele) +
                                                     QString(" to ") + QString::number(to_allele) +
                                                     QString(": </b> ") + str_mutrate_val) );
            }
        }
    }
    catch(...) {
        qDebug() << "Error while reading mutatio rates.";
    }


    // fitness range
    try {
        // dummy read just to throw us out if it doesn't exist
        std::string dummy_min_fitness = fits_constants::PARAM_ALLELE_MIN_FITNESS + std::to_string(0);
        std::string dummy_max_fitness = fits_constants::PARAM_ALLELE_MAX_FITNESS + std::to_string(0);
        auto dummy_val1 = my_zparams.GetFloat(dummy_min_fitness);
        auto dummy_val2 = my_zparams.GetFloat(dummy_max_fitness);

        ui->optSingleSimulation->setChecked(false);
        ui->optSingleSimulation->setEnabled(false);
        ui->optFitnessInference->setEnabled(true);
        ui->optFitnessInference->setChecked(true);
        ui->cmdGo->setEnabled(true);

        ui->txtAllParameters->append(QString("<br><b>Fitness Range<br>==============</b>") );

        for ( auto current_allele=0; current_allele<num_alleles; ++current_allele ) {
            std::string tmp_min_fitness = fits_constants::PARAM_ALLELE_MIN_FITNESS + std::to_string(current_allele);
            std::string tmp_max_fitness = fits_constants::PARAM_ALLELE_MAX_FITNESS + std::to_string(current_allele);

            //qDebug() << "reading fitness range " << QString::fromStdString(tmp_min_fitness) << QString::fromStdString(tmp_max_fitness);
            auto tmp_min_fitness_val = my_zparams.GetFloat(tmp_min_fitness);
            auto tmp_max_fitness_val = my_zparams.GetFloat(tmp_max_fitness);

            ui->txtAllParameters->append(QString("<b>Allele ") + QString::number(current_allele) +
                                         QString(" min:</b> ") + QString::number(tmp_min_fitness_val) +
                                         QString("<b> max:</b> ") + QString::number(tmp_max_fitness_val) );
        }
    }
    catch(...) {
        qDebug() << "error while reading fitness range data";
    }




    try {
        // initial frequencies

        // dummy read just to throw us out if it doesn't exist
        std::string dummy_initfreq_str = fits_constants::PARAM_ALLELE_INIT_FREQ + std::to_string(0);
        auto dummy_init_freq = my_zparams.GetFloat(dummy_initfreq_str);
        ui->txtAllParameters->append(QString("<br><b>Initial Frequencies<br>=====================</b>") );

        for ( auto current_allele=0; current_allele<num_alleles; ++current_allele ) {
            std::string tmp_initfreq_str = fits_constants::PARAM_ALLELE_INIT_FREQ + std::to_string(current_allele);

            auto tmp_init_freq = my_zparams.GetFloat(tmp_initfreq_str);

            ui->txtAllParameters->append( QString("<b>Allele ") + QString::number(current_allele) +
                                          QString(" frequency: </b> ") + QString::number(tmp_init_freq) );
        }
    }
    catch(...) {
        qDebug() << "error while reading ifitness range data";
    }


    try {
        // min/max mutation rates

        // dummy read just to throw us out if it doesn't exist
        std::string dummy_str_min_mutrate = fits_constants::PARAM_MIN_LOG_MUTATION_RATE + "0_0";
        std::string dummy_str_max_mutrate = fits_constants::PARAM_MAX_LOG_MUTATION_RATE + "0_0";
        auto dummy_min_mutrate_val = my_zparams.GetFloat(dummy_str_min_mutrate);
        auto dummy_max_mutrate_val = my_zparams.GetFloat(dummy_str_max_mutrate);
        ui->txtAllParameters->append(QString("<br><b>Mutation Rate Range<br>====================</b>") );

        ui->optSingleSimulation->setChecked(false);
        ui->optSingleSimulation->setEnabled(false);
        ui->optMutationInference->setEnabled(true);
        ui->optMutationInference->setChecked(true);
        ui->cmdGo->setEnabled(true);

        for ( auto from_allele=0; from_allele<num_alleles; ++from_allele ) {
            for ( auto to_allele=0; to_allele<num_alleles; ++to_allele ) {
                std::string tmp_str_min_mutrate = fits_constants::PARAM_MIN_LOG_MUTATION_RATE +
                        std::to_string(from_allele) +
                        "_" +
                        std::to_string(to_allele);

                std::string tmp_str_max_mutrate = fits_constants::PARAM_MAX_LOG_MUTATION_RATE +
                        std::to_string(from_allele) +
                        "_" +
                        std::to_string(to_allele);

                auto tmp_min_mutrate_val = my_zparams.GetFloat(tmp_str_min_mutrate);
                auto str_min_mutrate_val = QString::number(tmp_min_mutrate_val);

                auto tmp_max_mutrate_val = my_zparams.GetFloat(tmp_str_max_mutrate);
                auto str_max_mutrate_val = QString::number(tmp_max_mutrate_val);

                ui->txtAllParameters->append( QString("<b>From ") + QString::number(from_allele) +
                                              QString(" to ") + QString::number(to_allele) +
                                              QString(" min:</b> ") + str_min_mutrate_val +
                                              QString("<b> max:</b> ") + str_max_mutrate_val );

            }
        }
    }
    catch(...) {
        qDebug() << "error while reading ifitness range data";
    }


    try {
        // min/max population size

        // dummy read just to throw us out if it doesn't exist
        std::string dummy_str_min_popsize = fits_constants::PARAM_MIN_LOG_POPSIZE;
        std::string dummy_str_max_popsize = fits_constants::PARAM_MAX_LOG_POPSIZE;
        auto min_popsize_val = my_zparams.GetFloat(dummy_str_min_popsize);
        auto max_popsize_val = my_zparams.GetFloat(dummy_str_max_popsize);
        ui->txtAllParameters->append(QString("<br><b>Population Size Range<br>====================</b>") );

        ui->optSingleSimulation->setChecked(false);
        ui->optSingleSimulation->setEnabled(false);
        ui->optPopsizeInference->setEnabled(true);
        ui->optPopsizeInference->setChecked(true);
        ui->cmdGo->setEnabled(true);

        ui->txtAllParameters->append( QString("<b>Log min: </b>") + QString::number(min_popsize_val) +
                                      QString("<b> max:</b> ") + QString::number(max_popsize_val)  );
    }
    catch(...) {
        qDebug() << "error while reading ifitness range data";
    }


    ui->txtAllParameters->append("<br><i>--End.</i>");
    auto cur = ui->txtAllParameters->cursor();
    cur.setPos(1, 1);
    ui->txtAllParameters->setCursor(cur);
    loaded_parameters = true;
    on_optSingleSimulation_clicked();
}

void FitsGUI::on_cmdEditParameterFile_clicked()
{
    dlgEditTextFile dlg(this);

    dlg.LoadFile( ui->txtParameters->text() );
    dlg.exec();

    auto str_result = dlg.GetFileContent();

    // refresh
    on_cmdReloadParameters_clicked();
}

