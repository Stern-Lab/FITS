/*
    FITS - Flexible Inference from Time-Series data
    (c) 2016-2018 by Tal Zinger
    tal.zinger@outlook.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef FITSGUI_H
#define FITSGUI_H

#include "clsCMulatorABC.h"
#include "ActualDataFile.hpp"
#include "ZParams.h"
#include "qabc.h"
#include "dlgedittextfile.h"

#include <QMainWindow>
#include <QDialog>
#include <QMessageBox>
#include <QFileDialog>
#include <QDebug>
#include <QtConcurrent>
#include <QThread>



namespace Ui {
class FitsGUI;
}

class FitsGUI : public QMainWindow
{
    Q_OBJECT

public:
    explicit FitsGUI(QWidget *parent = 0);
    ~FitsGUI();

signals:
    void batch_completed(int percent_completed);
    void stopABC();


public slots:
    void on_batch_completed(int percent_completed);
    void on_ABC_stop();
    void on_ABC_completed();

    void on_sorting_complete();
    void on_distance_complete();
    void on_simulations_complete();

private slots:
    void on_cmdBrowseActualData_clicked();

    void on_cmdBrowseParameters_clicked();

    void on_cmdStop_clicked();


    void on_optSingleSimulation_clicked();

    void on_optFitnessInference_clicked();

    void on_radioButton_3_clicked();

    void on_radioButton_4_clicked();

    //void on_pushButton_2_clicked();

    void on_cmdSaveSummary_clicked();

    void on_cmdSavePosterior_clicked();

    void on_cmdGo_clicked();

    //void on_txtPopsize_textChanged(const QString &arg1);

    //void on_pushButton_clicked();

    void on_cmdReloadParameters_clicked();

    void on_cmdEditParameterFile_clicked();


private:

    // calculating rate
    std::chrono::time_point<std::chrono::high_resolution_clock> last_update;
    int last_percent;

    bool loaded_parameters;
    bool loaded_actual_data;

    FactorToInfer factor;
    std::size_t number_of_batches;
    std::size_t repeats;

    Ui::FitsGUI *ui;

    std::vector<SimulationResult> simulation_result_vector;

    ActualDataFile actual_data_file;
    ZParams my_zparams;

    QABC *qabc;

    QString str_summary;
    QString str_posterior;

    //void RunABCInferenceGUI( FactorToInfer factor, std::size_t number_of_batches, std::size_t repeats );
//void RunABCInferenceGUI();

};

#endif // FITSGUI_H
