/*
    FITS - Flexible Inference from Time-Series data
    (c) 2016-2018 by Tal Zinger
    tal.zinger@outlook.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef QABC_H
#define QABC_H

#include <QObject>
#include <QDebug>

#include "clsCMulatorABC.h"
#include "ResultsStats.hpp"

class QABC : public QObject
{
    Q_OBJECT
public:
    explicit QABC( ActualDataFile actual,  ZParams params, std::size_t reps, std::size_t batch_num, FactorToInfer f, QObject *parent = nullptr);

    std::vector<SimulationResult> GetResultsVector(bool only_accepted_results);

    void RunABCInferenceGUI();

    void SetActualData(  ) ;
    void SetParameters(  );

    void TestFunction();

    QString GetOutputText() { return strOutputSummary; }

signals:
    //void stopABC();

    void interruptedABC();
    void batch_completed(int percent_completed);
    void finishedABC();

    void finishedSimulations();
    void finishedDistanceCalculations();
    void finishedSorting();


public slots:
    void on_stop_ABC();

private:
    FactorToInfer factor;
    std::size_t number_of_batches;
    std::size_t repeats;
    std::size_t remaining_repeats;
    std::size_t repeats_in_batch;

    std::vector<SimulationResult> simulation_result_vector;

    ActualDataFile actual_data_file;
    ZParams my_zparams;

    bool is_allowed_to_run;

    QString strOutputSummary;
};

#endif // QABC_H
