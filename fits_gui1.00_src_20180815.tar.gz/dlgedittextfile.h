#ifndef DLGEDITTEXTFILE_H
#define DLGEDITTEXTFILE_H

#include <QDialog>
#include <QTextStream>
#include <QMessageBox>
#include <QString>
#include <QFile>

namespace Ui {
class dlgEditTextFile;
}

class dlgEditTextFile : public QDialog
{
    Q_OBJECT

public:
    explicit dlgEditTextFile(QWidget *parent = 0);
    ~dlgEditTextFile();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::dlgEditTextFile *ui;

    QString strContent;
    QString strFilename;

public:
    QString GetFileContent() { return strContent; }
    void SetFileContent(QString str);

    void LoadFile(QString filename);
    void SaveFile(QString filename);
};

#endif // DLGEDITTEXTFILE_H
