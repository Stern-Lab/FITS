/*
    FITS - Flexible Inference from Time-Series data
    (c) 2016-2018 by Tal Zinger
    tal.zinger@outlook.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "dlgedittextfile.h"
#include "ui_dlgedittextfile.h"

dlgEditTextFile::dlgEditTextFile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dlgEditTextFile)
{
    ui->setupUi(this);
}

dlgEditTextFile::~dlgEditTextFile()
{
    delete ui;
}

void dlgEditTextFile::on_buttonBox_accepted()
{
    strContent = ui->txtFile->toPlainText();
    SaveFile(strFilename);
}

void dlgEditTextFile::on_buttonBox_rejected()
{
    strContent = QString("");
}

void dlgEditTextFile::SetFileContent(QString str)
{
    ui->txtFile->setPlainText(str);
}

void dlgEditTextFile::LoadFile(QString filename)
{
    strFilename = filename;

    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for reading");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }


    QTextStream in(&file);

    ui->txtFile->setPlainText( in.readAll() );

    file.close();
}

void dlgEditTextFile::SaveFile(QString filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for writing");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }


    QTextStream out(&file);
    out << ui->txtFile->toPlainText();

    file.close();
}
