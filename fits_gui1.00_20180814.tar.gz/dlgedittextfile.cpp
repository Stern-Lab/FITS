#include "dlgedittextfile.h"
#include "ui_dlgedittextfile.h"

dlgEditTextFile::dlgEditTextFile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dlgEditTextFile)
{
    ui->setupUi(this);
}

dlgEditTextFile::~dlgEditTextFile()
{
    delete ui;
}

void dlgEditTextFile::on_buttonBox_accepted()
{
    strContent = ui->txtFile->toPlainText();
    SaveFile(strFilename);
}

void dlgEditTextFile::on_buttonBox_rejected()
{
    strContent = QString("");
}

void dlgEditTextFile::SetFileContent(QString str)
{
    ui->txtFile->setPlainText(str);
}

void dlgEditTextFile::LoadFile(QString filename)
{
    strFilename = filename;

    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for reading");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }


    QTextStream in(&file);

    ui->txtFile->setPlainText( in.readAll() );

    file.close();
}

void dlgEditTextFile::SaveFile(QString filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox msgBox;
        msgBox.setText("Error while opening file for writing");
        msgBox.setInformativeText(filename);
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
        return;
    }


    QTextStream out(&file);
    out << ui->txtFile->toPlainText();

    file.close();
}
